<script lang="ts">
  const modules = [
    'Organizations',
    'Participants',
    'Parents',
    'Program Directors',
    'Seasons',
    'Teams',
    'Badges',
    'Certifications',
    'Statistics',
    'Curriculum'
  ];
</script>

<svelte:head>
  <title>FGL_YOUTH</title>
  <meta name="description" content="FGL Youth Development and FLIHub starter app" />
</svelte:head>

<section class="hero">
  <p class="eyebrow">FGL Youth Development</p>
  <h1>Every kid can FLI.</h1>
  <p>
    Starter SvelteKit + PocketBase app for youth disc golf programs, participant profiles,
    badges, certifications, statistics, curriculum tracking, and program administration.
  </p>
</section>

<section class="grid">
  {#each modules as module}
    <article>{module}</article>
  {/each}
</section>

<style>
  :global(body) {
    margin: 0;
    font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: #0f172a;
    color: #f8fafc;
  }

  main {
    min-height: 100vh;
  }

  .hero {
    max-width: 960px;
    margin: 0 auto;
    padding: 6rem 1.5rem 3rem;
  }

  .eyebrow {
    text-transform: uppercase;
    letter-spacing: 0.15em;
    color: #93c5fd;
    font-weight: 700;
  }

  h1 {
    font-size: clamp(3rem, 8vw, 6rem);
    line-height: 0.95;
    margin: 0.5rem 0 1rem;
  }

  .hero p:last-child {
    max-width: 720px;
    color: #cbd5e1;
    font-size: 1.15rem;
  }

  .grid {
    max-width: 960px;
    margin: 0 auto;
    padding: 1rem 1.5rem 5rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
  }

  article {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 1rem;
    padding: 1.25rem;
    font-weight: 700;
  }
</style>
